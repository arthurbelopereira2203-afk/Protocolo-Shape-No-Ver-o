// Recebe os avisos de venda da Kiwify e libera ou bloqueia o acesso pelo e-mail do comprador.
import { createClient } from "npm:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("ok");

  // Senha secreta que você coloca na URL do webhook (?key=...)
  const key = new URL(req.url).searchParams.get("key");
  if (!key || key !== Deno.env.get("WEBHOOK_KEY")) {
    return new Response("unauthorized", { status: 401 });
  }

  let body: any;
  try { body = await req.json(); } catch { return new Response("bad request", { status: 400 }); }

  const event: string = body?.webhook_event_type ?? "";
  const email = String(body?.Customer?.email ?? "").trim().toLowerCase();
  if (!email) return new Response("sem e-mail");

  let status: "approved" | "refunded" | null = null;
  if (event === "order_approved" || event === "subscription_renewed") status = "approved";
  else if (event === "order_refunded" || event === "chargeback") status = "refunded";
  if (!status) return new Response("evento ignorado");

  const { error } = await supabase.from("purchases").upsert(
    { email, status, order_id: body?.order_id ?? null, updated_at: new Date().toISOString() },
    { onConflict: "email" },
  );
  if (error) { console.error(error); return new Response("erro", { status: 500 }); }
  return new Response("ok");
});
