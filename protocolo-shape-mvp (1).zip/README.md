# Protocolo Shape no Verão: MVP

Este projeto tem 4 partes:
- `index.html` + `config.js`: o app (site estático).
- `supabase/schema.sql`: banco de dados com contas, progresso e lista de compradores.
- `supabase/functions/kiwify-webhook`: recebe as vendas da Kiwify e libera ou bloqueia o acesso.

**Como funciona:** a cliente compra na Kiwify → a Kiwify avisa o seu servidor → o e-mail dela entra na lista de compradores → ela abre o app, digita o e-mail, recebe um código por e-mail e entra → o progresso fica salvo na conta dela, em qualquer aparelho. Em caso de reembolso ou chargeback, o acesso é bloqueado.

## Passo a passo (cerca de 1 hora)

### 1. Criar o projeto no Supabase
1. Crie uma conta grátis em supabase.com e um projeto novo. Guarde a senha do banco.
2. Abra **SQL Editor > New query**, cole o conteúdo de `supabase/schema.sql` e clique em **Run**.
3. Em **Project Settings > API**, copie a **Project URL** e a chave **anon public**.
4. Abra `config.js` e cole os dois valores. Nunca coloque a chave `service_role` no site.

### 2. Configurar o login por código
1. **Authentication > Providers**: confirme que o provedor **Email** está ativo.
2. **Authentication > Email Templates**: edite os modelos **Confirm signup** e **Magic Link** e inclua o código no texto, por exemplo: `Seu código de acesso: {{ .Token }}`. Sem isso, o e-mail chega só com link e o app não funciona.
3. **Configure um e-mail próprio de envio (SMTP).** O envio padrão do Supabase é muito limitado e, em projetos novos, pode enviar só para membros da sua equipe. Use um serviço como Resend ou Brevo (têm plano grátis): **Project Settings > Authentication > SMTP Settings**. Confira as regras atuais no painel do Supabase.
4. Em **Authentication > Rate Limits**, deixe o limite de e-mails compatível com o seu volume de vendas.

### 3. Publicar o webhook da Kiwify
Instale o Supabase CLI (supabase.com/docs/guides/cli) e, na pasta deste projeto:
```
supabase login
supabase link --project-ref SEU_REF
supabase secrets set WEBHOOK_KEY=UMA_SENHA_LONGA_E_ALEATORIA
supabase functions deploy kiwify-webhook --no-verify-jwt
```
(`SEU_REF` é o código que aparece na URL do projeto: `https://SEU_REF.supabase.co`. O `--no-verify-jwt` é necessário porque a Kiwify não envia login do Supabase; a proteção é a senha `?key=`.)

A URL do webhook fica assim:
`https://SEU_REF.supabase.co/functions/v1/kiwify-webhook?key=UMA_SENHA_LONGA_E_ALEATORIA`

### 4. Configurar a Kiwify
1. No painel da Kiwify, procure a área de **Webhooks** (em Apps). O caminho pode mudar, então confira no painel.
2. Crie um webhook com a URL acima, escolha o produto do protocolo e marque os eventos **Compra aprovada**, **Compra reembolsada** e **Chargeback**.
3. Na entrega do produto na Kiwify, coloque o link do app como acesso ao conteúdo.
4. Para os produtos da loja, crie cada um na Kiwify e cole os links de checkout em `config.js > links`, na ordem indicada no arquivo.

### 5. Publicar o app
1. Crie conta grátis na Netlify ou na Vercel.
2. Na Netlify, abra **Add new site > Deploy manually** e arraste a pasta do projeto (`index.html` e `config.js`). Você recebe um endereço.
3. No Supabase, em **Authentication > URL Configuration**, coloque esse endereço em **Site URL**.
4. Se tiver domínio próprio (ex.: `app.seusite.com`), conecte na Netlify ou na Vercel.

### 6. Testar antes de vender
1. Libere um e-mail seu pelo SQL Editor:
```
insert into purchases (email) values ('seu@email.com')
on conflict (email) do update set status = 'approved';
```
2. Abra o app, entre com esse e-mail, digite o código recebido e faça o questionário.
3. Entre por outro aparelho com o mesmo e-mail: o progresso deve aparecer.
4. Teste o bloqueio: `update purchases set status = 'refunded' where email = 'seu@email.com';` e tente entrar de novo.
5. Faça uma compra de teste real na Kiwify e confira em **Table Editor > purchases** se o e-mail apareceu.
6. Em **Edge Functions > kiwify-webhook > Logs**, veja se há erros.

## Antes de abrir as vendas
- Revisão dos treinos e receitas por um educador físico e um nutricionista.
- Política de privacidade e termos de uso (o app guarda peso e dados de saúde: dados sensíveis pela LGPD).
- Teste com 3 a 5 pessoas e em celulares diferentes.
- Se alguém comprar com um e-mail e tentar entrar com outro, não terá acesso: avise isso na entrega do produto.

## Pontos de atenção
- Quem não comprou consegue descobrir se um e-mail é de comprador (a tela avisa que não há compra). Para o MVP isso é aceitável, mas não coloque dados pessoais na lista de compradores além do e-mail.
- Se a mesma pessoa comprar de novo ou renovar, o acesso continua. Se pedir reembolso, é bloqueado.
- Não foi possível testar este projeto com o Supabase e a Kiwify reais. Siga a seção de testes com cuidado antes de vender.
